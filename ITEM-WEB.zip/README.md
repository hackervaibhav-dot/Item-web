<p align="center">
    <em><b>FF ITEMS</b></em>
</p>
<p align="center">An OpenSource Free Fire Item Search Website. Search by Keywords Name, Icon Name & Item ID!</p>
<br>

## Table of Contents
<b>1. [Project Structure](#project-structure)<br>
2. [Project Index](#project-index)<br>
3. [License](#license)
</b>

## Project Structure

```sh
└── ffitems
       ├── CNAME
       ├── CONTRIBUTING.md
       ├── LICENSE
       ├── README.md
       ├── assets
       │     ├── app.json
       │     ├── error-404.png
       │     ├── header.png
       │     └── og.png
       ├── index.html
       └── src
            ├── script.js
            └── styles.css
```

## Project Index
<details>
  <summary><i><b>FF ITEMS</i></b></summary>
  <details>
    <summary>main</summary>
    <blockquote>
      <table>
        <tr><td><b><a href="https://github.com/joya-das/ffitems/blob/main/README.md">README.md</a></b></td></tr>
        <tr><td><b><a href="https://github.com/joya-das/ffitems/blob/main/LICENSE">LICENSE</a></b></td></tr>
        <tr><td><b><a href="https://github.com/joya-das/ffitems/blob/main/CNAME">CNAME</a></b></td></tr>
        <tr><td><b><a href="https://github.com/joya-das/ffitems/tree/main/assets/">assets/</a></b></td></tr>
        <tr><td><b><a href="https://github.com/joya-das/ffitems/tree/main/.github/">.github/</a></b></td></tr>
        <tr><td><b><a href="https://github.com/joya-das/ffitems/tree/main/src/">src/</a></b></td></tr>
        <tr><td><b><a href="https://github.com/joya-das/ffitems/blob/main/index.html">index.html</a></b></td></tr>
      </table>
    </blockquote>
    <details>
      <summary>assets</summary>
      <blockquote>
        <table>
          <tr><td><b><a href="https://github.com/joya-das/ffitems/blob/main/assets/error-404.png">error-404.png</a></b></td></tr>
          <tr><td><b><a href="https://github.com/joya-das/ffitems/blob/main/assets/og.png">og.png</a></b></td></tr>
          <tr><td><b><a href="https://github.com/joya-das/ffitems/blob/main/assets/app.json">app.json</a></b></td></tr>
          <tr><td><b><a href="https://github.com/joya-das/ffitems/blob/main/assets/header.png">header.png</a></b></td></tr>
        </table>
      </blockquote>
    </details>
    <details>
      <summary>src</summary>
      <blockquote>
        <table>
          <tr><td><b><a href="https://github.com/joya-das/ffitems/blob/main/src/styles.css">styles.css</a></b></td></tr>
          <tr><td><b><a href="https://github.com/joya-das/ffitems/blob/main/src/script.js">script.js</a></b></td></tr>
        </table>
      </blockquote>
    </details>
    <details>
      <summary>.github</summary>
      <blockquote>
        <table>
          <tr><td><b><a href="https://github.com/joya-das/ffitems/tree/main/.github/ISSUE_TEMPLATE/">ISSUE_TEMPLATE/</a></b></td></tr>
          <tr><td><b><a href="https://github.com/joya-das/ffitems/blob/main/.github/ISSUE_TEMPLATE/bug_report.md">bug_report.md</a></b></td></tr>
        </table>
      </blockquote>
    </details>
  </details>
</details>


<details closed>
<summary><b>Contributing Guidelines</b></summary>

1. **Fork the Repository**: Start by forking the project repository to your GitHub account.
2. **Clone Locally**: Clone the forked repository to your local machine using a git client.
   ```sh
   git clone https://github.com/joya-das/ffitems
   ```
3. **Create a New Branch**: Always work on a new branch, giving it a descriptive name.
   ```sh
   git checkout -b new-feature-x
   ```
4. **Make Your Changes**: Develop and test your changes locally.
5. **Commit Your Changes**: Commit with a clear message describing your updates.
   ```sh
   git commit -m 'Implemented new feature x.'
   ```
6. **Push to GitHub**: Push the changes to your forked repository.
   ```sh
   git push origin new-feature-x
   ```
7. **Submit a Pull Request**: Create a PR against the original project repository. Clearly describe the changes and their motivations.
8. **Review**: Once your PR is reviewed and approved, it will be merged into the main branch. Congratulations on your contribution!
</details>

## License

This project is released under the [MIT License](LICENSE)
